<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Full Static</title>
</head>

<body>
  <nav>
    <a href="/">Home</a>
    <a href="/?page=about">About</a>
    <a href="/?page=contact">Contact</a>
  </nav>
  <h1>LKS Cyber Security Pemalang</h1>
  <p>
    Selamat datang di website LKS Cyber Security Pemalang. Website ini dibuat menggunakan teknologi statis.
  </p>
</body>

</html>