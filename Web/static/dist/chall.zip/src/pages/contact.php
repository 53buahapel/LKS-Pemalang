<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About</title>
</head>

<body>
  <nav>
    <a href="/">Home</a>
    <a href="/?page=about">About</a>
    <a href="/?page=contact">Contact</a>
  </nav>
  <h1>Contact</h1>
  <p>
    Jika Anda ingin menghubungi kami melalui kontak telepon, silakan hubungi nomor 081234567890. Jika Anda ingin mengirimkan email, silakan kirim ke email kami di
    <a href="mailto:user@example.com">
      user@example.com
    </a>
  </p>
</body>

</html>