<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About</title>
</head>

<body>
  <nav>
    <a href="/">Home</a>
    <a href="/?page=about">About</a>
    <a href="/?page=contact">Contact</a>
  </nav>
  <h1>Tentang CTF</h1>
  <p>
    Capture The Flag (CTF) adalah kompetisi yang biasanya diikuti oleh para mahasiswa atau profesional di bidang keamanan siber. Dalam kompetisi ini, peserta akan diberikan tantangan untuk menyelesaikan masalah keamanan siber yang beragam. Tantangan tersebut bisa berupa soal pemrograman, kriptografi, reverse engineering, dan lain-lain. - ChatGPT
  </p>
</body>

</html>